/*
	LIbreria para definir la IP Estatica del equipo cliente a monitorear y la IP y puerto del servidor de monitoreo
	Codificado  e implementado por Jose Luis Olivares, email: joseluiss_503@hotmail.com
	Version 1.0,    Junio 2017
*/

var cliente={
	IP:'10.23.135.136' //Escribir la IP estatica del equipo a monitorear
};

var servidor={
	IP:'http://10.23.223.68:3000' //IP y puerto del servidor de monitoreo, ex  'http://192.168.79.128:3000'
};